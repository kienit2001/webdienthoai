package com.shopdt.doandt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DoandtApplicationTests {

	@Test
	void contextLoads() {
	}

}
